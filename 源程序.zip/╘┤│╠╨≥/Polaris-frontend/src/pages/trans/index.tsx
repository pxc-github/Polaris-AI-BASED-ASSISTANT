import { transPOST } from '@/services/yubi/OcrPicTextController';
import { UploadOutlined } from '@ant-design/icons';
import {Button, Card, Col, Form, Input, message, Row, Select, Space, Spin, Upload} from 'antd';
import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';
import TextArea from "antd/es/input/TextArea";

/**
 * 添加机器翻译页面
 * @constructor
 */
const AddChart: React.FC = () => {
const [resResultText, setQuestionResult ] = useState<API.BiResponse | null>(null);
const [submitting, setSubmitting] = useState<boolean>(false);

const lang = [
  { value: 'cn', label: '中文' },
  { value: 'en', label: '英语' },
]

  /**
   * 提交
   * @param values
   */
  const onFinish = async (values: any) => {
    // 避免重复提交
    if (submitting) {
      return;
    }
    setSubmitting(true);
    // 对接后端，上传数据
    const params = {
      ...values
    };
    try {
      const res = await transPOST(params);
      if (!res?.data) {
        message.error(res?.message);
      } else {
        message.success('翻译成功');
        const resultText = JSON.parse(res.data.resultText)
        setQuestionResult(resultText)
      }
    } catch (e: any) {
      console.log(e)
      message.error('翻译失败:' + e.message);
    }
    setSubmitting(false);
  };

  return (
    <div className="add-chart">
      <Row gutter={24}>
        <Col span={24}>
          <Card title="机器翻译">
            <Form name="addChart" labelAlign="left" labelCol={{ span: 4 }}
                  wrapperCol={{ span: 16 }} onFinish={onFinish} initialValues={{}}>
              <Row gutter={24}>
                <Col span={12}>
                  <Form.Item name="from" label="源语言">
                    <Select options={lang} placeholder={"选择源语言"} />
                  </Form.Item>
                </Col>
                <Col span={12}>
                  <Form.Item name="to" label="目标语言">
                    <Select  options={lang} placeholder={"选择目标语言"} />
                  </Form.Item>
                </Col>
              <Col span={12}>
                <Form.Item name="sourceText" label="翻译内容">
                  <TextArea placeholder="请输入需要翻译的内容" />
                </Form.Item>
              </Col>
              </Row>

              <Row gutter={24}>
              <Col span={4}>
              <Form.Item wrapperCol={{ span: 8, offset: 0 }}>
                <Space>
                  <Button type="primary" htmlType="submit" loading={submitting} disabled={submitting}>
                    翻译
                  </Button>
                  <Button htmlType="reset">重置</Button>
                </Space>
              </Form.Item>
              </Col>
              </Row>
            </Form>
          </Card>
        </Col>
        <Col span={24} style={{ marginTop: '20px'}}>
          <Row gutter={24}>
            <Col span={24}>
              <Card title="翻译结果" style={{minHeight: '200px'}}>
                <ReactMarkdown>
                  {/*{chart?.genResult ? chart?.genResult : (submitting ? '正在分析, 请稍后...' : '请先提交分析数据')}*/}
                  { resResultText?.trans_result.dst }
                </ReactMarkdown>
                <Spin spinning={submitting} />
              </Card>
            </Col>
          </Row>
          {/*<Divider />*/}
        </Col>
      </Row>
    </div>
  );
};
export default AddChart;
