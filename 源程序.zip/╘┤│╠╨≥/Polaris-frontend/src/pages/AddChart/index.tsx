import { genChartByAiUsingPOST } from '@/services/yubi/chartController';
import { UploadOutlined } from '@ant-design/icons';
import {Button, Card, Col, Divider, Form, Input, message, Row, Select, Space, Spin, Upload} from 'antd';
import TextArea from 'antd/es/input/TextArea';
import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import ReactMarkdown from 'react-markdown';
/**
 * 添加图表页面
 * @constructor
 */
const AddChart: React.FC = () => {
const [chart, setChart] = useState<API.BiResponse>();
const [option, setOption] = useState<any>();
const [submitting, setSubmitting] = useState<boolean>(false);

  /**
   * 提交
   * @param values
   */
  const onFinish = async (values: any) => {
    // 避免重复提交
    if (submitting) {
      return;
    }
    setSubmitting(true);
    setChart(undefined);
    setOption(undefined);
    // 对接后端，上传数据
    const params = {
      ...values,
      file: undefined,
    };
    try {
      const res = await genChartByAiUsingPOST(params, {}, values.file.file.originFileObj);
      if (!res?.data) {
        message.error('分析失败');
      } else {
        message.success('分析成功');
        const chartOption = JSON.parse(res.data.genChart ?? '');
        if (!chartOption) {
          throw new Error('图表代码解析错误')
        } else {
          setChart(res.data);
          setOption(chartOption);
        }
      }
    } catch (e: any) {
      message.error('分析失败，' + e.message);
    }
    setSubmitting(false);
  };

  return (
    <div className="add-chart">
      <Row gutter={24}>
        <Col span={24}>
          <Card title="智能分析">
            <Form name="addChart" labelAlign="left" labelCol={{ span: 4 }}
                  wrapperCol={{ span: 16 }} onFinish={onFinish} initialValues={{}}>
              <Row gutter={24}>
              <Col span={12}>
              <Form.Item
                name="goal"
                label="分析目标"
                rules={[{ required: true, message: '请输入分析目标' }]}
              >
                <TextArea placeholder="请输入你的分析需求，比如：分析网站用户的增长情况" />
              </Form.Item>
              </Col>
              <Col span={12}>
              <Form.Item name="name" label="图表名称">
                <Input placeholder="请输入图表名称" />
              </Form.Item>
              </Col>
              </Row>
              <Row gutter={24}>
                <Col span={10}>
              <Form.Item name="chartType" label="图表类型">
                <Select
                  options={[
                    { value: '折线图', label: '折线图' },
                    { value: '柱状图', label: '柱状图' },
                    { value: '堆叠图', label: '堆叠图' },
                    { value: '饼图', label: '饼图' },
                    { value: '雷达图', label: '雷达图' },
                  ]}
                />
              </Form.Item>
                </Col>
                <Col span={10}>
                  <Form.Item name="file" label="原始数据">
                    <Upload name="file" maxCount={1}>
                      <Button icon={<UploadOutlined />}>上传 EXCEL 文件</Button>
                    </Upload>
                  </Form.Item>
                </Col>

              <Col span={4}>
              <Form.Item wrapperCol={{ span: 8, offset: 0 }}>
                <Space>
                  <Button type="primary" htmlType="submit" loading={submitting} disabled={submitting}>
                    提交
                  </Button>
                  <Button htmlType="reset">重置</Button>
                </Space>
              </Form.Item>
              </Col>
              </Row>
            </Form>
          </Card>
        </Col>
        <Col span={24} style={{ marginTop: '20px'}}>
          <Row gutter={24}>
            <Col span={12}>
              <Card title="分析结论" style={{minHeight: '200px'}}>
                <ReactMarkdown>{chart?.genResult ? chart?.genResult : (submitting ? '正在分析, 请稍后...' : '请先提交分析数据')}</ReactMarkdown>
                <Spin spinning={submitting} />
              </Card>
            </Col>

            <Col span={12}>
              <Card title="可视化图表" style={{minHeight: '200px'}}>
                {
                  option ? <ReactECharts option={option} /> : (submitting ? <div>正在分析, 请稍后...</div> : <div>请先提交分析数据</div>)
                }
                <Spin spinning={submitting}/>
              </Card>
            </Col>
          </Row>
          {/*<Divider />*/}
        </Col>
      </Row>
    </div>
  );
};
export default AddChart;
