import { ocrPicTextPOST } from '@/services/yubi/OcrPicTextController';
import { UploadOutlined } from '@ant-design/icons';
import {Button, Card, Col, Form, Input, message, Row, Space, Spin, Upload} from 'antd';
import React, { useState } from 'react';
import ReactMarkdown from 'react-markdown';

/**
 * 添加图像文字识别页面
 * @constructor
 */
const AddChart: React.FC = () => {

const [resResultText, setQuestionResult ] = useState<API.BiResponse | null>(null);
const [submitting, setSubmitting] = useState<boolean>(false);

  /**
   * 提交
   * @param values
   */
  const onFinish = async (values: any) => {
    // 避免重复提交
    if (submitting) {
      return;
    }
    setSubmitting(true);
    // 对接后端，上传数据
    const params = {
      ...values,
      file: undefined,
    };
    try {
      const res = await ocrPicTextPOST(params, {}, values.file.file.originFileObj);
      if (!res?.data) {
        message.error('分析失败');
      } else {
        let text = ''
        message.success('分析成功');
        const result = JSON.parse(res.data.result)
        for (let pages of result.pages) {
          for (let line of pages.lines) {
            for (let word of line.words) {
              text += word.content + ' '
            }
          }
        }
        setQuestionResult(text)
      }
    } catch (e: any) {
      message.error('分析失败');
    }
    setSubmitting(false);
  };

  return (
    <div className="add-chart">
      <Row gutter={24}>
        <Col span={24}>
          <Card title="图像文字识别">
            <Form name="addChart" labelAlign="left" labelCol={{ span: 4 }}
                  wrapperCol={{ span: 16 }} onFinish={onFinish} initialValues={{}}>
              <Row gutter={24}>
              {/*<Col span={12}>*/}
              {/*<Form.Item*/}
              {/*  name="name"*/}
              {/*  label="分析名称"*/}
              {/*  rules={[{ required: true, message: '请输入分析名称' }]}*/}
              {/*>*/}
              {/*  <Input placeholder="请输入分析名称" />*/}
              {/*</Form.Item>*/}
              {/*</Col>*/}
              <Col span={12}>
                <Form.Item name="file" label="分析图片">
                  <Upload name="file" maxCount={1}>
                    <Button icon={<UploadOutlined />}>上传文字分析图片</Button>
                  </Upload>
                </Form.Item>
              </Col>
              </Row>
              <Row gutter={24}>
              <Col span={4}>
              <Form.Item wrapperCol={{ span: 8, offset: 0 }}>
                <Space>
                  <Button type="primary" htmlType="submit" loading={submitting} disabled={submitting}>
                    提交
                  </Button>
                  <Button htmlType="reset">重置</Button>
                </Space>
              </Form.Item>
              </Col>
              </Row>
            </Form>
          </Card>
        </Col>
        <Col span={24} style={{ marginTop: '20px'}}>
          <Row gutter={24}>
            <Col span={24}>
              <Card title="识别结果" style={{minHeight: '200px'}}>
                <ReactMarkdown>
                  {/*{chart?.genResult ? chart?.genResult : (submitting ? '正在分析, 请稍后...' : '请先提交分析数据')}*/}
                  { resResultText }
                </ReactMarkdown>
                <Spin spinning={submitting} />
              </Card>
            </Col>
          </Row>
          {/*<Divider />*/}
        </Col>
      </Row>
    </div>
  );
};
export default AddChart;
