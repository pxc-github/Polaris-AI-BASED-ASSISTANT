import { IMAGES } from '@/constants';
import { PageContainer } from '@ant-design/pro-components';
import { Alert, Card, Carousel, Divider, Image, Typography } from 'antd';
import React, { useEffect, useState } from 'react';

/**
 * 每个单独的卡片，为了复用样式抽成了组件
 */
const { Title, Paragraph } = Typography;

const blockContent = `Polaris智能小助手是一款基于讯飞开放平台强大API的综合智能系统。旨在为大学生的学习生活赋能，涵盖数据分析、问题解答、OCR文字识别、机器翻译等多项功能。通过Polaris，用户能够以更高效的方式处理和分析数据，解答问题，进行文字识别，并实现多语言翻译，从而提升学习效率，方便日常学习生活。`
const Welcome: React.FC = () => {
  // 加载图片
  const [loadedImages, setLoadedImages] = useState([]);
  useEffect(() => {
    Promise.all(IMAGES)
      // @ts-ignore
      .then((images) => setLoadedImages(images))
      .catch((error) => console.error(error));
  }, []);

  return (
    <PageContainer content={''}>
      <Card>
        <Alert
          message={'欢迎使用Polaris智能小助手平台！'}
          type="success"
          showIcon
          banner
          style={{
            margin: -12,
            marginBottom: 48,
          }}
        />
        <Typography.Title
          level={1}
          style={{
            textAlign: 'center',
          }}
        >
          Polaris智能小助手
        </Typography.Title>
        <Paragraph style={{ color: '#000' }}>
        </Paragraph>
        <Paragraph style={{ color: '#000', fontWeight: 'bold' }}>
          <pre>{blockContent}</pre>
        </Paragraph>
        <Title level={2} style={{ color: '#000' }}>
          Polaris智能小助手功能介绍
        </Title>
        <Paragraph strong style={{ color: '#000' }}>
          1.
          智能数据分析功能：用户能够通过上传excel格式的数据表，输入自定义分析目标并选择生成表格的形式，系统将以清晰的文字描述和可视化图片的形式返回智能分析结果，帮助用户更深入理解数据。
        </Paragraph>
        <Paragraph strong style={{ color: '#000' }}>
          2.
          AI问答功能: 与传统的和大模型对话的方式不同，问题解答功能从三个方面重新定义了问题内容。用户按照系统的指引输入问题的不同纬度，使得智能回答更具体、全面，更有针对性。
        </Paragraph>
        <Paragraph strong style={{ color: '#000' }}>
          3.
          文字识别功能: Polaris支持用户上传含有文字的图片，系统将识别并返回文字内容。更重要的是，用户可以方便地复制识别到的文字，使得从图片中提取文字信息变得轻而易举，方便处理各类文档和图像资料。
        </Paragraph>
        <Paragraph strong style={{ color: '#000' }}>
          4.
          机器翻译功能: 用户只需粘贴或输入待翻译的文字，系统将快速进行翻译，并提供清晰的翻译结果。这一功能不仅方便用户的语言学习，还促进了跨文化交流，提升了语言应用的实际效果。
        </Paragraph>
        <br />
        <Divider style={{ color: 'black' }}>AIGC猫咪</Divider>
        <Paragraph strong style={{ color: '#000' }}>
          <Carousel autoplay autoplaySpeed={10000}>
            {loadedImages.map((image, index) => (
              <div key={index}>
                <Image src={image.default} />
              </div>
            ))}
          </Carousel>
        </Paragraph>
      </Card>
    </PageContainer>
  );
};

export default Welcome;
