package com.yupi.springbootinit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.springbootinit.model.entity.OcrPicText;
import com.yupi.springbootinit.model.entity.Trans;

public interface TransMapper extends BaseMapper<Trans> {

}




