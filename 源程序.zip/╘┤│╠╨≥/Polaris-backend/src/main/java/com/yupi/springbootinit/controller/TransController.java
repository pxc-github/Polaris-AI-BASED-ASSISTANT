package com.yupi.springbootinit.controller;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson2.JSONObject;
import com.yupi.springbootinit.api.TransApi;
import com.yupi.springbootinit.api.TransTest;
import com.yupi.springbootinit.common.BaseResponse;
import com.yupi.springbootinit.common.ErrorCode;
import com.yupi.springbootinit.common.ResultUtils;
import com.yupi.springbootinit.exception.ThrowUtils;
import com.yupi.springbootinit.model.entity.Trans;
import com.yupi.springbootinit.service.TransService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("/trans")
@Slf4j
public class TransController {

    @Resource
    TransService transService;

    @PostMapping("/add")
    public BaseResponse<?> add(@RequestBody Trans trans){

        ThrowUtils.throwIf(StrUtil.isBlank(trans.getFrom()), ErrorCode.PARAMS_ERROR, "请选择源语言");
        ThrowUtils.throwIf(StrUtil.isBlank(trans.getTo()), ErrorCode.PARAMS_ERROR, "请选择翻译目标语言");
        ThrowUtils.throwIf(StrUtil.isBlank(trans.getSourceText()), ErrorCode.PARAMS_ERROR, "翻译内容不能为空");

        JSONObject jsonObject = TransApi.trans(trans.getFrom(), trans.getTo(), trans.getSourceText());

        if (null == jsonObject) {
            trans.setStatus("failed");
            transService.save(trans);
            return ResultUtils.error(ErrorCode.OPERATION_ERROR, "翻译失败");
        }

        trans.setResultText(jsonObject.toJSONString());
        trans.setStatus("success");
        transService.save(trans);

        return ResultUtils.success(trans);
    }
}
