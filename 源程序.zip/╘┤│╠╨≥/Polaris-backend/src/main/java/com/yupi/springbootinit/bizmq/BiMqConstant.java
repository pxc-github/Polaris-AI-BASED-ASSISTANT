package com.yupi.springbootinit.bizmq;

/**
 * 给交换机一个固定的值
 */
public interface BiMqConstant {
    String BI_EXCHANGE_NAME = "bi_xhl_exchange";
    String BI_QUEUE_NAME = "bi_xhl_queue";

    String BI_ROUTING_KEY = "bi_xhl_routingKey";
}
