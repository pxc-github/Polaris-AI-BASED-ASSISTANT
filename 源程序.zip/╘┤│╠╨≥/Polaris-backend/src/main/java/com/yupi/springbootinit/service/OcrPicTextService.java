package com.yupi.springbootinit.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yupi.springbootinit.model.entity.OcrPicText;

/**
 * 图像文字识别
 */
public interface OcrPicTextService extends IService<OcrPicText> {

}
