package com.yupi.springbootinit.controller;

import cn.hutool.core.io.FileUtil;
import com.alibaba.fastjson2.JSONObject;
import com.yupi.springbootinit.api.OcrPicTextApi;
import com.yupi.springbootinit.common.BaseResponse;
import com.yupi.springbootinit.common.ErrorCode;
import com.yupi.springbootinit.common.ResultUtils;
import com.yupi.springbootinit.constant.CommonConstant;
import com.yupi.springbootinit.exception.BusinessException;
import com.yupi.springbootinit.exception.ThrowUtils;
import com.yupi.springbootinit.model.entity.Chart;
import com.yupi.springbootinit.model.entity.OcrPicText;
import com.yupi.springbootinit.model.entity.User;
import com.yupi.springbootinit.model.vo.BiResponse;
import com.yupi.springbootinit.service.OcrPicTextService;
import com.yupi.springbootinit.utils.ExcelUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/picOcr")
@Slf4j
public class PicTextOCRController {

    @Resource
    OcrPicTextService ocrPicTextService;

    @PostMapping("/add")
    public BaseResponse<?> add(@RequestPart("file") MultipartFile multipartFile, HttpServletRequest request) throws IOException {
        String name = request.getParameter("name");
        // 校验
        //ThrowUtils.throwIf(StringUtils.isBlank(name), ErrorCode.PARAMS_ERROR, "分析名称为空");
        ThrowUtils.throwIf(StringUtils.isNotBlank(name) && name.length() > 100, ErrorCode.PARAMS_ERROR, "名称过长");
        // 校验文件
        long size = multipartFile.getSize();
        String originalFilename = multipartFile.getOriginalFilename();
        // 校验文件大小
        final long ONE_MB = 1024 * 1024L;
        ThrowUtils.throwIf(size > ONE_MB, ErrorCode.PARAMS_ERROR, "文件超过 1M");
        // 校验文件后缀 aaa.png
        String suffix = FileUtil.getSuffix(originalFilename);
        final List<String> validFileSuffixList = Arrays.asList("png", "jpg","jpeg","webp");
        ThrowUtils.throwIf(!validFileSuffixList.contains(suffix), ErrorCode.PARAMS_ERROR, "文件后缀非法");

        // User loginUser = userService.getLoginUser(request);
        // 限流判断，每个用户一个限流器
        // redisLimiterManager.doRateLimit("genChartByAi_" + loginUser.getId());


        OcrPicText ocrPicText = new OcrPicText();
        ocrPicText.setName(name);
        ocrPicTextService.save(ocrPicText);

        JSONObject jsonObject = OcrPicTextApi.analyse(multipartFile.getBytes());
        if (null == jsonObject) {
            ocrPicText.setStatus("failed");
            ocrPicTextService.updateById(ocrPicText);
            ThrowUtils.throwIf(true, ErrorCode.SYSTEM_ERROR, "未分析出结果");
        }

        ocrPicText.setResult(jsonObject.toJSONString());
        ocrPicText.setOcrFile(multipartFile.getInputStream().toString());
        ocrPicText.setStatus("success");
        ocrPicTextService.updateById(ocrPicText);

        //返回给前端一个统一的信息
        return ResultUtils.success(ocrPicText);
    }

}
