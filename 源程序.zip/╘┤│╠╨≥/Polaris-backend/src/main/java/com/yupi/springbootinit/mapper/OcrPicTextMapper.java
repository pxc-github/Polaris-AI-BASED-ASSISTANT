package com.yupi.springbootinit.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yupi.springbootinit.model.entity.OcrPicText;

import java.util.List;
import java.util.Map;

public interface OcrPicTextMapper extends BaseMapper<OcrPicText> {

}




