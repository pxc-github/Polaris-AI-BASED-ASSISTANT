package com.yupi.springbootinit.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.yupi.springbootinit.mapper.OcrPicTextMapper;
import com.yupi.springbootinit.model.entity.OcrPicText;
import com.yupi.springbootinit.service.OcrPicTextService;
import org.springframework.stereotype.Service;

@Service
public class OcrPicTextServiceImpl extends ServiceImpl<OcrPicTextMapper, OcrPicText> implements OcrPicTextService {
}
