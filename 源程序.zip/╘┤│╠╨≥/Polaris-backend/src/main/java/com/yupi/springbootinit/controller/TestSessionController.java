package com.yupi.springbootinit.controller;

import com.yupi.springbootinit.common.BaseResponse;
import com.yupi.springbootinit.common.ResultUtils;
import com.yupi.springbootinit.model.dto.aiassistant.GenChatByAiRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/session")
@Slf4j
public class TestSessionController {

    @GetMapping("/set")
    public BaseResponse<?> set(HttpServletRequest request) {
        request.getSession().setAttribute("sss", "oak");
        return ResultUtils.success("");
    }

    @GetMapping("/get")
    public BaseResponse<?> get(HttpServletRequest request) {
        request.getSession().setAttribute("sss", "oak");
        return ResultUtils.success("");
    }

}
