package com.yupi.springbootinit.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yupi.springbootinit.model.entity.OcrPicText;
import com.yupi.springbootinit.model.entity.Trans;

/**
 * 机器翻译识别
 */
public interface TransService extends IService<Trans> {

}
