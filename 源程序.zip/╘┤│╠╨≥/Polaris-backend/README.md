
## 快速上手

> 所有需要修改的地方都标记了 `todo`，便于大家找到修改的位置~

### 修改项目 maven 配置
```yml
在 idea 的设置菜单中找到 maven 选项，并将 maven 对应的 仓库地址和
setting 配置文件改成自己电脑的配置。取消 ide 默认勾选的设置。
```

### MySQL 数据库
1) 如果是本地运行需要启动本地的 MySQL 服务
2) 修改 `application.yml` 的数据库配置为你自己的：

```yml
spring:
  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://localhost:3306/my_db
    username: root
    password: 123456
```

2）执行 `sql/create_table.sql` 中的数据库语句，自动创建库表


### Redis 分布式登录
1) 如果是本地运行需要启动本地的 Redis 服务
2) 修改 `application.yml` 的 Redis 配置为你自己的：

```yml
spring:
  redis:
    database: 1
    host: localhost
    port: 6379
    timeout: 5000
    password: 123456
```

### RabbitMQ 分布式登录
1) 如果是本地运行需要启动本地的 RabbitMQ 服务
2）修改 `application.yml` 的 RabbitMQ 配置为你自己的：

```yml
spring:
    rabbitmq:
    host: 你的 RabbitMQ IP
    password: 123456
    username: admin
    port: 5672
    listener:
      direct:
        acknowledge-mode: manual
```
